<html>
<head>
<title>
</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href='https://fonts.googleapis.com/css?family=Gugi' rel='stylesheet'>
</head>
<body>
		<div class="text">
			<br><br><br><br><br><br><br>
			<h4> All Rights Reserved &copy; 2021</h4>
			<br><br>
		</div>

</body>
</html>