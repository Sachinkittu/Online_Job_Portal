<?php
$con = mysqli_connect('localhost','sachin','sachin','quiz1');
if(mysqli_connect_error()){
    $message="My sql error :".mysqli_connect_error();
    die("Could not connect to the database");
}
else
{
    
}
?>
