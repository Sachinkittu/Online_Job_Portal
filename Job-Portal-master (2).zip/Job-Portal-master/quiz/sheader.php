<?php
include 'master.php';
//To Handle Session Variables on This Page
session_start();

//If user Not logged in then redirect them back to homepage. 
if(empty($_SESSION['id_user'])) {
  header("Location: ../index.php");
  exit();
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>
     Job Portal
    </title>
	<!-- <link rel="icon" href="icon10.png"> -->
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href='https://fonts.googleapis.com/css?family=Gugi' rel='stylesheet'>
</head>
<body>

	<div class="bgimage">
		<div class="menu">
			<div class="leftmenu">
				<h4> JobPortal </h4>
			</div>
			<div class="rightmenu">
				<ul>
					<li id="firstlist"><a href="../index.php"> HOME </a></li>
					<li><a href="sprofile.php"> YOUR PROFILE </a> </li>
					<li><a href="../logout.php"> LOGOUT </a></li>
				</ul>
			</div>

		</div>
<br>

</body>
</html>