<?php
include 'master.php';
include 'fheader.php';

?>
<html>
<head>
	<title>
        HOME
    </title>
</head>
<body>	
<br><br>
		<div class="text">
			<h2> WELCOME! </h2><br>
<br><br>
			<a href="createquiz.html">
			<button id="buttonwide"> Create A New Quiz </button> 
			</a>
			&nbsp; &nbsp;
			<a href="fscore.html">
			<button id="buttonone"> view scores </button> 
			</a>
		</div>
<br><br>
<?php include "footer.php";?>
<br><br>
</body>
</html>