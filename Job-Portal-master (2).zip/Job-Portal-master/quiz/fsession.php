<?php
include "master.php";
include "fchecklogin.php";

if($_SESSION['id_company']=='')
	{
	echo "<script> alert('Please login first!');
	window.location.href='../logout.php';
	</script>";
	exit();
	}
else
	{
		$id = $_SESSION['id_company'];
		include "master.php";
		$sql = "SELECT * FROM company WHERE id_company='$id' ";
		$result = mysqli_query($con,$sql);
		$count = mysqli_num_rows($result);

		if($count != 1)
	{
echo "<script>
alert('You're not authorised for this page!');
window.location.href='../index.php';
</script>";
	exit();
	}
else
	{

	}
}
?>