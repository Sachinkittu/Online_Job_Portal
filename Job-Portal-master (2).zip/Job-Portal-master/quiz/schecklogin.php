
<?php
include "master.php";
include "slogin.php";

if($_SESSION['id_user']=='')
	{
echo "<script>
alert('Please login first!');
window.location.href='login.html';
</script>";
	exit();
	}
else
	{

	}
?>


